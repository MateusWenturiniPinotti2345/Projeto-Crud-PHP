<?php
class Modelveiculos
{
    // Propriedades da classe para representar dados do veículo
    public $codigo;
    public $placa;
    public $renavam;
    public $dataCompra;
    public $marca;
    public $modelo;
    public $cor;
    public $tipo;
    public $anoModelo;
    public $anoFabricacao;

    // Método para obter a data de compra formatada
    public function getDataCompraFormatada()
    {
        // Verifica se a data de compra não é nula
        if ($this->dataCompra !== null) {
            // Converte a data de compra para um timestamp e formata como 'd/m/Y'
            $tempoCompra = strtotime($this->dataCompra);
            return date('d/m/Y', $tempoCompra);
        }

        // Retorna null se a data de compra for nula
        return null;
    }
}
?>
