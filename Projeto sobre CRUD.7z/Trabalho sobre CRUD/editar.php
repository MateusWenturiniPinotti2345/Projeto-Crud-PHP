<?php

require 'classes/bancoDeDados/veiculos.php';

// Verifica se os dados foram enviados via POST antes de acessá-los


    $c = new Veiculo();

    // Crie uma instância do VeiculoModel e atribua os valores
    $veiculo = new Modelveiculos();
    
    $veiculo->codigo = $_POST['codigo'] ; '';
    $veiculo->placa =   $_POST['placa'] ;'';
    $veiculo->renavam =  $_POST['renavam'] ; '';
    $veiculo->dataCompra =  $_POST['data_compra'] ; '';
    $veiculo->marca =  $_POST['marca'] ; '';
    $veiculo->modelo =  $_POST['modelo'] ; '';
    $veiculo->cor =  $_POST['cor'] ; '';
    $veiculo->tipo =  $_POST['tipo'] ; '';
    $veiculo->anoModelo =  $_POST['ano_modelo'] ; '';
    $veiculo->anoFabricacao =  $_POST['ano_fabricacao'] ; '';

    // Use o método correto ao chamar a função de atualizar (se o método certo for atualizar)
  
    $c->atualizarVeiculo($veiculo);
    
    header('Location: index.php');


?>
