<?php
// Inclui o arquivo que contém a definição da classe Modelveiculos
require 'classes/bancoDeDados/veiculos.php';

// Define variáveis iniciais
$titulo = 'Novo veiculo';
$acao = 'cadastro.php';
$veiculo = new Modelveiculos();

// Se o parâmetro 'codigo' estiver presente na query string, é uma edição
if (isset($_GET['codigo'])) {
    $codigo = $_GET['codigo'];
    $titulo = 'Editar veiculo';
    $acao = 'editar.php';

    // Cria uma instância da classe Veiculo e obtém os dados do veículo a ser editado
    $c = new Veiculo();
    $veiculo = $c->getVeiculo($codigo);
} else if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Se o formulário foi submetido via método POST

    // Inicializa uma nova instância da classe Modelveiculos
    $veiculo = new Modelveiculos();

    // Atribui os valores dos campos do formulário aos atributos da instância
    $veiculo->placa = $_POST['placa'];
    $veiculo->renavam = $_POST['renavam'];
    $veiculo->dataCompra = $_POST['data_compra'];
    $veiculo->marca = $_POST['marca'];
    $veiculo->modelo = $_POST['modelo'];
    $veiculo->cor = $_POST['cor'];
    $veiculo->tipo = $_POST['tipo'];
    $veiculo->anoModelo = $_POST['ano_modelo'];
    $veiculo->anoFabricacao = $_POST['ano_fabricacao'];

    // Validar os campos obrigatórios
    if (empty($veiculo->placa) || empty($veiculo->marca)) {
        echo "Por favor, preencha todos os campos obrigatórios.";
    } else {
        // Faça algo com os dados, como salvar no banco de dados
        $c = new Veiculo();
        $c->inserirVeiculo($veiculo);

        // Redireciona para alguma página após o processamento
        header('Location: index.php');
        exit();
    }
}
?>




<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $titulo; ?></title>
    <link rel="stylesheet" href="cadastrostyle.css">
</head>

<body>
    <h2><?php echo $titulo; ?></h2>
    
    <form action="<?php echo $acao; ?>" method="post">
        <!-- Adicione um campo oculto para o código do veículo -->
        <input type="hidden" value="<?php echo $veiculo->codigo ?? ''; ?>" name="codigo" id="codigo" />
        
        <label for="placa">Placa:</label>
        <input type="text" value="<?php echo $veiculo->placa ?? ''; ?>" id="placa" name="placa" required />
        
        <label for="renavam">Renavam:</label>
        <input type="text" value="<?php echo $veiculo->renavam ?? ''; ?>" id="renavam" name="renavam" required />
        
        <label for="data_compra">Data da Compra:</label>
        <input type="date" value="<?php echo $veiculo->dataCompra ?? ''; ?>" id="data_compra" name="data_compra" required />
        
        <label for="marca">Marca:</label>
        <input type="text" value="<?php echo $veiculo->marca ?? ''; ?>" id="marca" name="marca" required />
        
        <label for="modelo">Modelo:</label>
        <input type="text" value="<?php echo $veiculo->modelo ?? ''; ?>" id="modelo" name="modelo" />
        
        <label for="cor">Cor:</label>
        <input type="text" value="<?php echo $veiculo->cor ?? ''; ?>" id="cor" name="cor" />
        
        <label for="tipo">Tipo:</label>
        <select id="tipo" name="tipo" required>
            <option value="carro" <?php echo isset($veiculo->tipo) && $veiculo->tipo == 'carro' ? 'selected' : ''; ?>>Carro</option>
            <option value="caminhonete" <?php echo isset($veiculo->tipo) && $veiculo->tipo == 'caminhonete' ? 'selected' : ''; ?>>caminhonete</option>
        </select>
        
        <label for="ano_modelo">Ano Modelo:</label>
        <input type="text" value="<?php echo $veiculo->anoModelo ?? ''; ?>" id="ano_modelo" name="ano_modelo" />
        
        <label for="ano_fabricacao">Ano Fabricação:</label>
        <input type="text" value="<?php echo $veiculo->anoFabricacao ?? ''; ?>" id="ano_fabricacao" name="ano_fabricacao" />
        
        <input type="submit" value="Salvar" />
    </form>
    
</body>

</html>
