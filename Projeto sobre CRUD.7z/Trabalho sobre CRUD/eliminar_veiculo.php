<?php
// Importa a classe Veiculo
require 'classes/bancoDeDados/veiculos.php';

// Cria uma instância da classe Veiculo
$c = new Veiculo();

// Obtém o parâmetro 'codigoEliminar' da query string
$codigoEliminar = $_GET['codigoEliminar'];

// Chama o método eliminarveiculo da instância da classe Veiculo
$c->eliminarveiculo($codigoEliminar);

// Redireciona para a página index.php após a exclusão
header('Location: index.php');
?>
