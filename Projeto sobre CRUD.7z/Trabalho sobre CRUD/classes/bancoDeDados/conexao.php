<?php

class Conexao
{
    public function getConexao()
    {
        $host = "localhost";
        $porta = "3306";
        $dbname = 'veiculos';
        
        $usuario = "root";
        $senha = "";

        try {
            $con = new PDO(
                "mysql:host={$host};port={$porta};dbname={$dbname}", 
                $usuario,
                $senha
            );

            // Define o PDO para lançar exceções em caso de erro
            $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            return $con;
        } catch (PDOException $e) {
            // Em caso de erro, imprime a mensagem de erro
            echo "Erro de conexão: " . $e->getMessage();
            exit();
        }
    }
}

?>
