<?php
// Inclui o arquivo de conexão e a definição da classe Modelveiculos
require 'conexao.php';
require 'model/Modelveiculos.php';

class Veiculo
{
    private $conexao;

    // Construtor que inicializa a conexão
    public function __construct()
    {
        $con = new Conexao();
        $this->conexao = $con->getConexao();
    }

    // Mapeia os resultados da consulta para objetos Modelveiculos
    private function mapearParaModelo($q)
    {
        $listaDeVeiculos = [];

        foreach ($q as $dados) {
            $veiculo = new Modelveiculos();
            $veiculo->codigo = $dados['codigo'];
            $veiculo->placa = $dados['placa'];
            $veiculo->renavam = $dados['renavam'];
            $veiculo->dataCompra = $dados['data_compra'];
            $veiculo->marca = $dados['marca'];
            $veiculo->modelo = $dados['modelo'];
            $veiculo->cor = $dados['cor'];
            $veiculo->tipo = $dados['tipo'];
            $veiculo->anoModelo = $dados['ano_modelo'];
            $veiculo->anoFabricacao = $dados['ano_fabricacao'];
            $listaDeVeiculos[] = $veiculo;
        }

        return $listaDeVeiculos;
    }

    // Lista todos os veículos
    public function listar()
    {
        $sql = 'SELECT * FROM veiculo';
        $q = $this->conexao->prepare($sql);
        $q->execute();
        return $this->mapearParaModelo($q);
    }

    // Excluir um veículo por código
    public function eliminarVeiculo($codigo)
    {
        $sql = 'DELETE FROM veiculo WHERE codigo = :codigo';
        $q = $this->conexao->prepare($sql);
        $q->bindParam(':codigo', $codigo);
        $q->execute();
    }

    // Insere um novo veículo
    public function inserirVeiculo($veiculo)
    {
        $sql = "INSERT INTO veiculo (placa, renavam, data_compra, marca, modelo, cor, tipo, ano_modelo, ano_fabricacao) 
                VALUES (:placa, :renavam, :data_compra, :marca, :modelo, :cor, :tipo, :ano_modelo, :ano_fabricacao)";
        $q = $this->conexao->prepare($sql);
        $q->bindParam(':placa', $veiculo->placa);
        $q->bindParam(':renavam', $veiculo->renavam);
        $q->bindParam(':data_compra', $veiculo->dataCompra);
        $q->bindParam(':marca', $veiculo->marca);
        $q->bindParam(':modelo', $veiculo->modelo);
        $q->bindParam(':cor', $veiculo->cor);
        $q->bindParam(':tipo', $veiculo->tipo);
        $q->bindParam(':ano_modelo', $veiculo->anoModelo);
        $q->bindParam(':ano_fabricacao', $veiculo->anoFabricacao);
        $q->execute();

        // Retorna o último ID inserido
        return $this->conexao->lastInsertId();
    }

    // Atualiza um veículo
    public function atualizarVeiculo($veiculo)
    {
        $sql = "UPDATE veiculo SET placa = :placa, renavam = :renavam, data_compra = :data_compra,
                marca = :marca, modelo = :modelo, cor = :cor, tipo = :tipo,
                ano_modelo = :ano_modelo, ano_fabricacao = :ano_fabricacao 
                WHERE codigo = :codigo";

        $q = $this->conexao->prepare($sql);
        $q->bindParam(':placa', $veiculo->placa);
        $q->bindParam(':renavam', $veiculo->renavam);
        $q->bindParam(':data_compra', $veiculo->dataCompra);
        $q->bindParam(':marca', $veiculo->marca);
        $q->bindParam(':modelo', $veiculo->modelo);
        $q->bindParam(':cor', $veiculo->cor);
        $q->bindParam(':tipo', $veiculo->tipo);
        $q->bindParam(':ano_modelo', $veiculo->anoModelo);
        $q->bindParam(':ano_fabricacao', $veiculo->anoFabricacao);
        $q->bindParam(':codigo', $veiculo->codigo);

        $q->execute();
    }

    // Pesquisa veículo por código
    public function pesquisarPorCodigo($codigo)
    {
        $sql = 'SELECT * FROM veiculo WHERE codigo = :codigo';
        $q = $this->conexao->prepare($sql);
        $q->bindParam(':codigo', $codigo);
        $q->execute();
        return $this->mapearParaModelo($q);
    }

    // Pesquisa veículo por placa
    public function pesquisarPorPlaca($placa)
    {
        $sql = 'SELECT * FROM veiculo WHERE placa = :placa';
        $q = $this->conexao->prepare($sql);
        $q->bindParam(':placa', $placa);
        $q->execute();
        return $this->mapearParaModelo($q);
    }

    // Pesquisa veículo por renavam
    public function pesquisarPorRenavam($renavam)
    {
        $sql = 'SELECT * FROM veiculo WHERE renavam = :renavam';
        $q = $this->conexao->prepare($sql);
        $q->bindParam(':renavam', $renavam);
        $q->execute();
        return $this->mapearParaModelo($q);
    }

    // Obtém um veículo por código
    public function getVeiculo($codigo)
    {
        $arrayVeiculo = $this->pesquisarPorCodigo($codigo);

        if (count($arrayVeiculo) > 0) {
            return $arrayVeiculo[0];
        }

        return null;
    }
}
?>
