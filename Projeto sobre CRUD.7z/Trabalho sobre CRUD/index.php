<?php
// Inclui o arquivo que contém a definição da classe Veiculo
require 'classes/bancoDeDados/veiculos.php';

// Cria uma instância da classe Veiculo
$c = new Veiculo();

// Inicializa um array para armazenar os veículos resultantes da consulta
$veiculos = [];

// Verifica se o parâmetro 'codigo' está presente na URL
if (isset($_GET['codigo'])) {
    $codigo = $_GET['codigo'];
    // Pesquisa veículos por código
    $veiculos = $c->pesquisarPorCodigo($codigo);
} 
// Verifica se o parâmetro 'placa' está presente na URL
else if (isset($_GET['placa'])) {
    $placa = $_GET['placa'];
    // Pesquisa veículos por placa
    $veiculos = $c->pesquisarPorPlaca($placa);
} 
// Verifica se o parâmetro 'renavam' está presente na URL
else if (isset($_GET['renavam'])) {
    $renavam = $_GET['renavam'];
    // Pesquisa veículos por renavam
    $veiculos = $c->pesquisarPorRenavam($renavam);
} 
// Se nenhum parâmetro específico for fornecido, lista todos os veículos
else {
    $veiculos = $c->listar(); 
}
?>



<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Veículos</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="container">
        <h2 class="mt-3">Lista de Veículos</h2>
        <br>
        <a href="cadastro.php" class="btn btn-primary mt-3 mb-2">Cadastrar Veículo</a>

        <h6 class="mt-4">Pesquisar</h6>
        <form action="index.php" method="get" class="mb-4">
            <div class="form-row">
                <div class="form-group col-md-3">
                    <label for="codigo">Código:</label>
                    <input type="text" class="form-control" id="codigo" name="codigo">
                </div>
                <div class="form-group col-md-3">
                    <label for="placa">Placa:</label>
                    <input type="text" class="form-control" id="placa" name="placa">
                </div>
                <div class="form-group col-md-3">
                    <label for="renavam">Renavam:</label>
                    <input type="text" class="form-control" id="renavam" name="renavam">
                </div>
                <div class="form-group col-md-3">
                    <label for="data_compra">Data da Compra:</label>
                    <input type="date" class="form-control" id="data_compra" name="data_compra">
                </div>
            </div>
            <input type="submit" class="btn btn-success" value="Pesquisar">
        </form>

        <?php if (!empty($veiculos)) : ?>
            <table class="table">
                <thead class="thead-light">
                    <tr>
                        <th>Código</th>
                        <th>Placa</th>
                        <th>Renavam</th>
                        <th>Data da Compra</th>
                        <th>Marca</th>
                        <th>Modelo</th>
                        <th>Cor</th>
                        <th>Tipo</th>
                        <th>Ano Modelo</th>
                        <th>Ano Fabricação</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($veiculos as $veiculo) : ?>
                        <tr>
                            <td><?php echo $veiculo->codigo; ?></td>
                            <td><?php echo $veiculo->placa; ?></td>
                            <td><?php echo $veiculo->renavam; ?></td>
                            <td><?php echo $veiculo->dataCompra; ?></td>
                            <td><?php echo $veiculo->marca; ?></td>
                            <td><?php echo $veiculo->modelo; ?></td>
                            <td><?php echo $veiculo->cor; ?></td>
                            <td><?php echo $veiculo->tipo; ?></td>
                            <td><?php echo $veiculo->anoModelo; ?></td>
                            <td><?php echo $veiculo->anoFabricacao; ?></td>
                            <td>
                                <!-- Formulário de edição -->
                                <form action="cadastro.php" method="get" style="display: inline;">
                                <input type="hidden" name="codigo" value="<?php echo $veiculo->codigo; ?>">
                                <button type="submit" class="btn btn-editar">Editar</button>
                                </form>


                                <!-- Formulário de exclusão -->
                                <form action="excluir.php" method="get" style="display: inline;">
                                    <input type="hidden" name="codigo" value="<?php echo $veiculo->codigo; ?>">
                                    <a  class="btn btn-excluir"  href="eliminar_veiculo.php?codigoEliminar=<?php echo $veiculo->codigo; ?>">
                                    Excluir</a>
                                   
                                   
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else : ?>
            <p>Nenhum veículo encontrado.</p>
        <?php endif; ?>
    </div>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>

</html>