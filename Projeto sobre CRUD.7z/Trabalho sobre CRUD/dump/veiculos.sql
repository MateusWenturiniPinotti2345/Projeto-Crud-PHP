-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 03/10/2023 às 20:27
-- Versão do servidor: 10.4.28-MariaDB
-- Versão do PHP: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `veiculos`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `veiculo`
--

CREATE TABLE `veiculo` (
  `codigo` int(11) NOT NULL,
  `placa` varchar(20) DEFAULT NULL,
  `Renavam` varchar(20) DEFAULT NULL,
  `data_compra` date DEFAULT NULL,
  `marca` varchar(50) DEFAULT NULL,
  `modelo` varchar(50) DEFAULT NULL,
  `cor` varchar(20) DEFAULT NULL,
  `tipo` varchar(20) DEFAULT NULL,
  `ano_modelo` int(11) DEFAULT NULL,
  `ano_fabricacao` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Despejando dados para a tabela `veiculo`
--

INSERT INTO `veiculo` (`codigo`, `placa`, `Renavam`, `data_compra`, `marca`, `modelo`, `cor`, `tipo`, `ano_modelo`, `ano_fabricacao`) VALUES
(13, 'JUQ4526', '43811724879', '2023-10-23', 'Mercedes-Benz', 'SLK-300 2.0 Turbo 245cv Aut.', 'Vermelho', 'caminhonete', 2001, 1995),
(14, 'HZK9496', '08741872272', '2023-10-12', 'CHANGAN', 'MINI STAR CE 1.0 8V 53cv ', 'Bege', 'carro', 2001, 2004),
(15, 'JRN1210', '55241643756', '2023-10-10', 'Ferrari', '348 GTS 3.4', 'Dourado', 'caminhonete', 1993, 1992),
(16, 'LXO4434', '30211055508', '2020-05-10', 'Seat', 'Inca 1.6L', 'Cinza', 'carro', 1999, 2000),
(17, 'MGI8423', '08624911190', '2023-10-20', 'Citroen', 'Xsara GLX/ Paris 2.0 16V', 'Laranja', 'carro', 2012, 2010);

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `veiculo`
--
ALTER TABLE `veiculo`
  ADD PRIMARY KEY (`codigo`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `veiculo`
--
ALTER TABLE `veiculo`
  MODIFY `codigo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
